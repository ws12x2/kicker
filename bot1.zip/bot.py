"""
Kod orqali post (video/rasm/matn) yuboruvchi Telegram bot.

ISHLASH PRINSIPI:

ADMIN uchun (/add):
    1) Botga /add buyrug'ini yuboring
    2) Bot "postni yuboring" deb so'raydi -> siz istalgan turdagi xabar
       yuborasiz: video, rasm, hujjat, yoki oddiy matn
    3) Bot "endi kodlarni yozing" deb so'raydi -> siz shu post uchun
       BIR NECHTA kodni vergul bilan ajratib yozasiz, masalan:
           12,avatar,avatr,avatar2
       (bir nechta kod yozish - foydalanuvchi imlo xatolarini hisobga olish
       uchun, masalan "avatar" ham, "avatr" ham shu postga olib kelishi uchun)
    4) Bot "endi tugma nomini yozing" deb so'raydi -> "🎬 Barcha postlar"
       ro'yxatida shu post qaysi nom bilan tugma sifatida chiqishini yozasiz,
       masalan: Avatar: Suvning yo'li (2022)
    5) Bot "✅ Saqlandi" deb javob beradi

    Bekor qilish uchun istalgan vaqtda /cancel yozing.

ADMIN PANEL (/admin):
    Botga /admin buyrug'ini yuborsangiz, quyidagi imkoniyatlarga ega
    inline tugmali panel chiqadi:
        ➕ Yangi post qo'shish  - /add bilan bir xil oqim, faqat tugma orqali
        ✏️ Postlarni tahrirlash - mavjud postlar ro'yxati chiqadi, har birini
                                   tanlab: kodlarini almashtirish, tugma
                                   nomini o'zgartirish yoki postni butunlay
                                   o'chirish mumkin

FOYDALANUVCHI uchun:
    Botga shunchaki kodni yozadi, masalan: avatar
    -> bot mos postni (qanday turda saqlangan bo'lishidan qat'i nazar -
       video, rasm yoki matn) topib, foydalanuvchiga yuboradi.

    ADMINDAN BOSHQA (oddiy) foydalanuvchilar bilan suhbatda, bot har safar
    xabar yuborgach, o'zidan oldingi xabarni EMAS, balki O'ZIDAN OLDINGI
    XABARDAN OLDINGI xabarni avtomatik o'chiradi - shu orqali har doim
    so'nggi 2 ta xabar (foydalanuvchining kodi + bot javobi) ko'rinishda
    qoladi, undan oldingi tarix esa tozalanadi. Pastdagi tugmalar har bir
    javobga qayta biriktiriladi, shuning uchun ular hech qachon yo'qolmaydi.

MUHIM: bot faylni hech qachon o'ziga yuklamaydi - faqat admin bilan bo'lgan
suhbatdagi asl xabarni Telegram serverlari orqali NUSXALAB (copy_message)
foydalanuvchiga yuboradi. Shu sababli fayl hajmi (hatto to'liq kino bo'lsa
ham) muammo qilmaydi.

O'RNATISH:
    pip install python-telegram-bot==21.6

ISHGA TUSHIRISH:
    1) BOT_TOKEN ni pastda o'z tokeningizga almashtiring (@BotFather dan oling)
    2) ADMIN_IDS ro'yxatiga o'z Telegram ID raqamingizni yozing
       (ID ni bilish uchun @userinfobot ga /start yuboring)
    3) python bot.py
"""

import asyncio
import logging
import os
import sqlite3
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    KeyboardButton,
)
from telegram.ext import (
    ApplicationBuilder,
    ContextTypes,
    CommandHandler,
    MessageHandler,
    ConversationHandler,
    CallbackQueryHandler,
    filters,
)

# ============ SOZLAMALAR ============
# BOT_TOKEN va DB_PATH avval Railway/server "Variables" bo'limidan o'qiladi
# (agar bo'lmasa, pastdagi standart qiymat ishlatiladi - masalan kompyuterda
# sinab ko'rish uchun).
BOT_TOKEN = os.environ.get("BOT_TOKEN", "BOT_TOKEN_BU_YERGA")
ADMIN_IDS = [123456789]                    # Sizning Telegram user ID(lar)ingiz
DB_PATH = os.environ.get("DB_PATH", "movies.db")

BTN_KINOLAR = "🎬 Barcha postlar"
BTN_VIP = "⭐ VIP"
VIP_CODE = "VIP"   # Admin qaysi postga shu kodni bersa ("vip" deb yozsa ham
                    # bo'ladi - kodlar avtomatik katta harfga o'giriladi),
                    # o'sha post ⭐ VIP tugmasi bosilganda yuboriladi.
# =====================================

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

WAITING_POST, WAITING_CODES, WAITING_BUTTON_NAME = range(3)  # ConversationHandler holatlari


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ============ BAZA ============

def _migrate_codes_table_if_needed(cur):
    """
    Eski versiyalarda 'codes' jadvalida 'id' ustuni bo'lmagan bo'lishi mumkin.
    Agar shunday bo'lsa, jadvalni ma'lumotlarni yo'qotmasdan yangi tuzilishga
    avtomatik o'tkazadi.
    """
    cur.execute("PRAGMA table_info(codes)")
    columns = [row[1] for row in cur.fetchall()]
    if not columns:
        return  # jadval hali umuman yaratilmagan - keyin normal yaratiladi
    if "id" in columns:
        return  # allaqachon yangi tuzilishda

    logger.info("Eski 'codes' jadvali topildi, yangi tuzilishga o'tkazilmoqda...")
    cur.execute("ALTER TABLE codes RENAME TO codes_old")
    cur.execute(
        """
        CREATE TABLE codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            post_id INTEGER NOT NULL,
            FOREIGN KEY (post_id) REFERENCES posts (post_id)
        )
        """
    )
    cur.execute("INSERT INTO codes (code, post_id) SELECT code, post_id FROM codes_old")
    cur.execute("DROP TABLE codes_old")
    logger.info("Migratsiya tugadi.")


def _migrate_posts_table_if_needed(cur):
    """Eski 'posts' jadvalida 'button_name' ustuni bo'lmasligi mumkin - qo'shamiz."""
    cur.execute("PRAGMA table_info(posts)")
    columns = [row[1] for row in cur.fetchall()]
    if not columns:
        return
    if "button_name" not in columns:
        logger.info("'posts' jadvaliga 'button_name' ustuni qo'shilmoqda...")
        cur.execute("ALTER TABLE posts ADD COLUMN button_name TEXT")


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS posts (
            post_id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER NOT NULL,
            message_id INTEGER NOT NULL,
            preview TEXT,
            button_name TEXT,
            added_by INTEGER
        )
        """
    )
    _migrate_posts_table_if_needed(cur)
    _migrate_codes_table_if_needed(cur)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            post_id INTEGER NOT NULL,
            FOREIGN KEY (post_id) REFERENCES posts (post_id)
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            chat_id INTEGER PRIMARY KEY,
            first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()
    conn.close()


def save_post(chat_id: int, message_id: int, preview: str, button_name: str, added_by: int) -> int:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """INSERT INTO posts (chat_id, message_id, preview, button_name, added_by)
           VALUES (?, ?, ?, ?, ?)""",
        (chat_id, message_id, preview, button_name, added_by),
    )
    post_id = cur.lastrowid
    conn.commit()
    conn.close()
    return post_id


def save_codes(codes: list, post_id: int):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    for code in codes:
        # Kod allaqachon mavjud bo'lsa - post_id'ni yangilaymiz (qayta bog'lash),
        # aks holda yangi qator qo'shamiz (insert tartibi id orqali saqlanadi).
        cur.execute(
            """INSERT INTO codes (code, post_id) VALUES (?, ?)
               ON CONFLICT(code) DO UPDATE SET post_id = excluded.post_id""",
            (code.strip().upper(), post_id),
        )
    conn.commit()
    conn.close()


def get_post_by_code(code: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """SELECT p.chat_id, p.message_id, p.preview
           FROM codes c JOIN posts p ON c.post_id = p.post_id
           WHERE c.code = ?""",
        (code.strip().upper(),),
    )
    row = cur.fetchone()
    conn.close()
    return row  # (chat_id, message_id, preview) yoki None


def delete_code(code: str) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DELETE FROM codes WHERE code = ?", (code.strip().upper(),))
    deleted = cur.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def list_all_codes():
    """
    Har bir post uchun faqat BIRINCHI qo'shilgan kodni qaytaradi (soddalik uchun).
    Tugma matni sifatida admin kiritgan 'button_name' ishlatiladi; agar u
    kiritilmagan bo'lsa (eski postlar), avtomatik 'preview' ishlatiladi.
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """SELECT c.code, COALESCE(p.button_name, p.preview) AS label, p.post_id
           FROM codes c JOIN posts p ON c.post_id = p.post_id
           WHERE c.id = (SELECT MIN(id) FROM codes WHERE post_id = p.post_id)
           ORDER BY p.post_id"""
    )
    rows = cur.fetchall()
    conn.close()
    return rows


def get_all_posts():
    """Barcha postlarni (post_id, nom) ko'rinishida qaytaradi - admin panel uchun."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT post_id, COALESCE(button_name, preview) AS label FROM posts ORDER BY post_id"
    )
    rows = cur.fetchall()
    conn.close()
    return rows


def get_codes_for_post(post_id: int):
    """Berilgan post uchun barcha kodlarni ro'yxat sifatida qaytaradi."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT code FROM codes WHERE post_id = ? ORDER BY id", (post_id,))
    rows = [r[0] for r in cur.fetchall()]
    conn.close()
    return rows


def replace_codes_for_post(post_id: int, codes: list):
    """Berilgan postning ESKI barcha kodlarini o'chirib, YANGI kodlar bilan almashtiradi."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DELETE FROM codes WHERE post_id = ?", (post_id,))
    conn.commit()
    conn.close()
    save_codes(codes, post_id)


def update_post_button_name(post_id: int, button_name: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("UPDATE posts SET button_name = ? WHERE post_id = ?", (button_name, post_id))
    conn.commit()
    conn.close()


def delete_post(post_id: int):
    """Postni va unga bog'liq BARCHA kodlarni butunlay o'chiradi."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DELETE FROM codes WHERE post_id = ?", (post_id,))
    cur.execute("DELETE FROM posts WHERE post_id = ?", (post_id,))
    conn.commit()
    conn.close()


def save_user(chat_id: int):
    """Botdan foydalangan har bir foydalanuvchini (reklama tarqatish uchun) eslab qoladi."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (chat_id) VALUES (?)", (chat_id,))
    conn.commit()
    conn.close()


def get_all_user_chat_ids(exclude_admins: bool = True):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT chat_id FROM users")
    rows = [r[0] for r in cur.fetchall()]
    conn.close()
    if exclude_admins:
        rows = [cid for cid in rows if cid not in ADMIN_IDS]
    return rows


# ============ YORDAMCHI FUNKSIYALAR ============

def make_preview(message) -> str:
    """Post uchun qisqa tavsif (ichki, admin uchun)."""
    if message.text:
        return message.text.strip()[:50]
    if message.caption:
        return message.caption.strip()[:50]
    if message.video:
        return "[video]"
    if message.photo:
        return "[rasm]"
    if message.document:
        return "[hujjat]"
    if message.audio:
        return "[audio]"
    if message.voice:
        return "[ovozli xabar]"
    if message.animation:
        return "[gif]"
    if message.sticker:
        return "[stiker]"
    return "[post]"


def parse_codes(text: str):
    """"12,avatar,avatr" -> ['12', 'AVATAR', 'AVATR'] (bo'sh qatorlar chiqarib tashlanadi)."""
    raw_parts = text.split(",")
    codes = [p.strip() for p in raw_parts if p.strip()]
    return codes


async def track_and_trim(update: Update, context: ContextTypes.DEFAULT_TYPE, sent_message, include_incoming: bool = True):
    """
    ADMINDAN BOSHQA foydalanuvchilar bilan suhbatda, chatdagi xabarlar
    tarixini (shu chat uchun context.chat_data ichida) kuzatib boradi va
    har safar yangi xabar yuborilgach, SO'NGGI 2 TADAN BOSHQA barcha eski
    xabarlarni o'chirib tashlaydi. Natijada chatda doim faqat oxirgi
    almashinuv (foydalanuvchi kodi/tugmasi + bot javobi) ko'rinishda qoladi.

    Eslatma: tarix botning joriy ishga tushishi davomida xotirada saqlanadi -
    bot qayta ishga tushirilsa, eski (avvalgi sessiyadagi) xabarlar
    "unutiladi" va endi avtomatik o'chirilmaydi.
    """
    user_id = update.effective_user.id
    if is_admin(user_id):
        return

    chat_id = update.effective_chat.id
    history = context.chat_data.setdefault("recent_ids", [])

    if include_incoming and update.message is not None:
        if not history or history[-1] != update.message.message_id:
            history.append(update.message.message_id)

    if sent_message is not None and hasattr(sent_message, "message_id"):
        history.append(sent_message.message_id)

    to_delete = history[:-2]
    keep = history[-2:]

    for mid in to_delete:
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=mid)
        except Exception:
            # Xabar allaqachon o'chirilgan, juda eski (48 soatdan katta),
            # yoki umuman mavjud emas bo'lishi mumkin - e'tiborsiz qoldiramiz.
            pass

    context.chat_data["recent_ids"] = keep


# ============ /add SUHBATI (ADMIN) ============

async def add_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/add buyrug'i orqali HAM, admin panelidagi "Yangi post qo'shish"
    tugmasi orqali HAM ishga tushishi mumkin."""
    user_id = update.effective_user.id
    prompt_text = (
        "🎬 Postni yuboring (video, rasm, hujjat, yoki oddiy matn bo'lishi mumkin).\n\n"
        "Bekor qilish uchun /cancel yozing."
    )

    if update.callback_query:
        query = update.callback_query
        await query.answer()
        if not is_admin(user_id):
            await query.edit_message_text("⛔️ Sizda film qo'shish huquqi yo'q.")
            return ConversationHandler.END
        await query.edit_message_text(prompt_text)
        return WAITING_POST

    if not is_admin(user_id):
        await update.message.reply_text("⛔️ Sizda film qo'shish huquqi yo'q.")
        return ConversationHandler.END

    await update.message.reply_text(prompt_text)
    return WAITING_POST


async def add_receive_post(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    preview = make_preview(message)

    # Postning o'zini vaqtincha saqlab qo'yamiz (kodlar va tugma nomi
    # kelgandan keyin bazaga yozamiz)
    context.user_data["pending_post"] = {
        "chat_id": message.chat_id,
        "message_id": message.message_id,
        "preview": preview,
    }

    await update.message.reply_text(
        f"✅ Post qabul qilindi: {preview}\n\n"
        "Endi shu post uchun kodlarni vergul bilan ajratib yozing.\n"
        "Masalan: 12,avatar,avatr,avatar2\n\n"
        "Bekor qilish uchun /cancel yozing."
    )
    return WAITING_CODES


async def add_receive_codes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pending = context.user_data.get("pending_post")
    if not pending:
        await update.message.reply_text(
            "⚠️ Avval /add buyrug'i bilan boshlang."
        )
        return ConversationHandler.END

    codes = parse_codes(update.message.text or "")
    if not codes:
        await update.message.reply_text(
            "❌ Hech qanday kod topilmadi. Kodlarni vergul bilan ajratib yozing, "
            "masalan: 12,avatar,avatr\n\nYoki /cancel bilan bekor qiling."
        )
        return WAITING_CODES

    pending["codes"] = codes

    await update.message.reply_text(
        "✅ Kodlar qabul qilindi.\n\n"
        "Endi shu post uchun TUGMA NOMINI yozing - bu nom "
        f'"{BTN_KINOLAR}" ro\'yxatida shu post tugmasi sifatida chiqadi.\n'
        "Masalan: Avatar: Suvning yo'li (2022)\n\n"
        "Bekor qilish uchun /cancel yozing."
    )
    return WAITING_BUTTON_NAME


async def add_receive_button_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pending = context.user_data.get("pending_post")
    if not pending or "codes" not in pending:
        await update.message.reply_text(
            "⚠️ Avval /add buyrug'i bilan boshlang."
        )
        return ConversationHandler.END

    button_name = (update.message.text or "").strip()
    if not button_name:
        await update.message.reply_text(
            "❌ Tugma nomi bo'sh bo'lishi mumkin emas. Iltimos, nom yozing, "
            "yoki /cancel bilan bekor qiling."
        )
        return WAITING_BUTTON_NAME

    user_id = update.effective_user.id
    post_id = save_post(
        pending["chat_id"], pending["message_id"], pending["preview"], button_name, user_id
    )
    save_codes(pending["codes"], post_id)

    context.user_data.pop("pending_post", None)

    codes_str = ", ".join(pending["codes"])
    await update.message.reply_text(
        f"✅ Saqlandi!\nTugma nomi: {button_name}\nKodlar: {codes_str}"
    )
    return ConversationHandler.END


async def add_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("pending_post", None)
    await update.message.reply_text("Bekor qilindi.")
    return ConversationHandler.END


# ============ ODDIY BUYRUQLAR ============

def main_menu_markup():
    keyboard = [[KeyboardButton(BTN_KINOLAR), KeyboardButton(BTN_VIP)]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user(update.effective_chat.id)
    sent = await update.message.reply_text(
        "Salom! 🎬\n\n"
        "Kerakli postni olish uchun menga kodni yuboring, masalan: avatar\n"
        "Yoki pastdagi tugmalardan foydalaning.",
        reply_markup=main_menu_markup(),
    )
    await track_and_trim(update, context, sent)


async def list_movies(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    keyboard = None if is_admin(user_id) else main_menu_markup()

    rows = list_all_codes()
    if not rows:
        sent = await update.message.reply_text(
            "Hozircha bazada postlar yo'q.", reply_markup=keyboard
        )
        await track_and_trim(update, context, sent)
        return

    inline_keyboard = [
        [InlineKeyboardButton(text=f"🎬 {label}", callback_data=f"code:{code}")]
        for code, label, post_id in rows
    ]
    markup = InlineKeyboardMarkup(inline_keyboard)

    sent = await update.message.reply_text(
        "🎬 Mavjud postlar (tugmani bosing):",
        reply_markup=markup,
    )
    await track_and_trim(update, context, sent)


async def delete_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("⛔️ Sizda bu buyruqdan foydalanish huquqi yo'q.")
        return

    if not context.args:
        await update.message.reply_text("Foydalanish: /delete KOD")
        return

    code = context.args[0]
    if delete_code(code):
        await update.message.reply_text(f"🗑 {code} o'chirildi.")
    else:
        await update.message.reply_text(f"{code} topilmadi.")


# ============ ADMIN PANEL (/admin) ============

WAITING_EDIT_VALUE = 100  # Tahrirlash suhbati uchun alohida ConversationHandler holati
WAITING_BROADCAST_POST = 200  # Reklama tarqatish suhbati uchun alohida holat


def admin_menu_markup():
    keyboard = [
        [InlineKeyboardButton("➕ Yangi post qo'shish", callback_data="adm:add")],
        [InlineKeyboardButton("✏️ Postlarni tahrirlash", callback_data="adm:editlist")],
        [InlineKeyboardButton("📢 Reklama tarqatish", callback_data="adm:broadcast")],
    ]
    return InlineKeyboardMarkup(keyboard)


async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("⛔️ Sizda admin panelidan foydalanish huquqi yo'q.")
        return
    await update.message.reply_text("⚙️ Admin panel:", reply_markup=admin_menu_markup())


async def adm_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(update.effective_user.id):
        return
    await query.edit_message_text("⚙️ Admin panel:", reply_markup=admin_menu_markup())


async def render_edit_list(query):
    """Tahrirlash uchun postlar ro'yxatini (post_id, nom) inline tugmalar sifatida chizadi."""
    posts = get_all_posts()
    if not posts:
        keyboard = [[InlineKeyboardButton("🔙 Orqaga", callback_data="adm:menu")]]
        await query.edit_message_text(
            "Hozircha postlar yo'q.", reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    keyboard = [
        [InlineKeyboardButton(f"🎬 {label}", callback_data=f"adm:editpost:{post_id}")]
        for post_id, label in posts
    ]
    keyboard.append([InlineKeyboardButton("🔙 Orqaga", callback_data="adm:menu")])
    await query.edit_message_text(
        "✏️ Tahrirlash uchun postni tanlang:", reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def adm_editlist_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(update.effective_user.id):
        return
    await render_edit_list(query)


async def adm_postdetail_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(update.effective_user.id):
        return

    post_id = int(query.data.split(":")[2])
    codes = get_codes_for_post(post_id)
    codes_str = ", ".join(codes) if codes else "(kodlar yo'q)"

    keyboard = [
        [InlineKeyboardButton("✏️ Kodlarni tahrirlash", callback_data=f"adm:editcodes:{post_id}")],
        [InlineKeyboardButton("✏️ Tugma nomini tahrirlash", callback_data=f"adm:editname:{post_id}")],
        [InlineKeyboardButton("🗑 Postni o'chirish", callback_data=f"adm:delpost:{post_id}")],
        [InlineKeyboardButton("🔙 Orqaga", callback_data="adm:editlist")],
    ]
    await query.edit_message_text(
        f"🎬 Post #{post_id}\nKodlar: {codes_str}",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def adm_delpost_confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(update.effective_user.id):
        return

    post_id = int(query.data.split(":")[2])
    keyboard = [
        [InlineKeyboardButton("✅ Ha, o'chirish", callback_data=f"adm:delconfirm:{post_id}")],
        [InlineKeyboardButton("❌ Bekor qilish", callback_data=f"adm:editpost:{post_id}")],
    ]
    await query.edit_message_text(
        "⚠️ Haqiqatan ham bu postni butunlay o'chirmoqchimisiz?\n"
        "(post va unga bog'liq BARCHA kodlar o'chiriladi)",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def adm_delpost_do_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(update.effective_user.id):
        return

    post_id = int(query.data.split(":")[2])
    delete_post(post_id)
    await render_edit_list(query)


async def edit_field_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin "Kodlarni tahrirlash" yoki "Tugma nomini tahrirlash" tugmasini bosganda ishga tushadi."""
    query = update.callback_query
    await query.answer()
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END

    parts = query.data.split(":")  # "adm:editcodes:5" yoki "adm:editname:5"
    field_key = parts[1]
    post_id = int(parts[2])

    context.user_data["edit_post_id"] = post_id

    if field_key == "editcodes":
        context.user_data["edit_field"] = "codes"
        await query.edit_message_text(
            "✏️ Ushbu post uchun YANGI kodlarni vergul bilan ajratib yozing "
            "(eski kodlar butunlay almashtiriladi):\n"
            "Masalan: 12,avatar,avatr\n\n"
            "Bekor qilish uchun /cancel yozing."
        )
    else:  # "editname"
        context.user_data["edit_field"] = "name"
        await query.edit_message_text(
            "✏️ Ushbu post uchun YANGI tugma nomini yozing:\n\n"
            "Bekor qilish uchun /cancel yozing."
        )

    return WAITING_EDIT_VALUE


async def edit_receive_value(update: Update, context: ContextTypes.DEFAULT_TYPE):
    post_id = context.user_data.get("edit_post_id")
    field = context.user_data.get("edit_field")

    if post_id is None or field is None:
        await update.message.reply_text("⚠️ Sessiya topilmadi. /admin orqali qaytadan boshlang.")
        return ConversationHandler.END

    text = (update.message.text or "").strip()

    if field == "codes":
        codes = parse_codes(text)
        if not codes:
            await update.message.reply_text(
                "❌ Kodlar topilmadi. Vergul bilan ajratib qaytadan yozing, "
                "yoki /cancel bilan bekor qiling."
            )
            return WAITING_EDIT_VALUE
        replace_codes_for_post(post_id, codes)
        await update.message.reply_text(f"✅ Kodlar yangilandi: {', '.join(codes)}")
    else:  # "name"
        if not text:
            await update.message.reply_text(
                "❌ Tugma nomi bo'sh bo'lishi mumkin emas. Qaytadan yozing, "
                "yoki /cancel bilan bekor qiling."
            )
            return WAITING_EDIT_VALUE
        update_post_button_name(post_id, text)
        await update.message.reply_text(f"✅ Tugma nomi yangilandi: {text}")

    context.user_data.pop("edit_post_id", None)
    context.user_data.pop("edit_field", None)
    return ConversationHandler.END


async def edit_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("edit_post_id", None)
    context.user_data.pop("edit_field", None)
    await update.message.reply_text("Bekor qilindi.")
    return ConversationHandler.END


# ============ REKLAMA TARQATISH (/admin -> 📢 Reklama tarqatish) ============

async def broadcast_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin "📢 Reklama tarqatish" tugmasini bosganda ishga tushadi."""
    query = update.callback_query
    await query.answer()
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END

    user_count = len(get_all_user_chat_ids())
    await query.edit_message_text(
        "📢 Reklama uchun postni yuboring (video, rasm, hujjat yoki oddiy matn "
        "bo'lishi mumkin).\n\n"
        f"Bu post botdan foydalangan barcha foydalanuvchilarga ({user_count} ta) "
        "yuboriladi.\n\n"
        "Bekor qilish uchun /cancel yozing."
    )
    return WAITING_BROADCAST_POST


async def broadcast_receive_post(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin reklama postini yuborganda - uni barcha foydalanuvchilarga tarqatadi."""
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END

    message = update.message
    admin_chat_id = message.chat_id
    admin_message_id = message.message_id

    user_ids = get_all_user_chat_ids()
    if not user_ids:
        await message.reply_text("⚠️ Hozircha botdan foydalangan hech kim yo'q.")
        return ConversationHandler.END

    status_msg = await message.reply_text(
        f"📢 Yuborilmoqda... (0/{len(user_ids)})"
    )

    success = 0
    failed = 0

    for i, uid in enumerate(user_ids, start=1):
        try:
            await context.bot.copy_message(
                chat_id=uid,
                from_chat_id=admin_chat_id,
                message_id=admin_message_id,
            )
            success += 1
        except Exception:
            # Foydalanuvchi botni bloklagan, akkaunt o'chirilgan va h.k. -
            # bunday xatolar oddiy holat, jarayonni to'xtatmaymiz.
            failed += 1

        # Telegram'ning yuborish tezligi cheklovlariga tegib ketmaslik uchun
        # kichik pauza qo'shamiz (soniyasiga ~20 xabar).
        await asyncio.sleep(0.05)

        # Har 20 ta yuborishda holatni yangilab turamiz
        if i % 20 == 0:
            try:
                await status_msg.edit_text(f"📢 Yuborilmoqda... ({i}/{len(user_ids)})")
            except Exception:
                pass

    await status_msg.edit_text(
        f"✅ Reklama yuborildi!\n"
        f"Muvaffaqiyatli: {success}\n"
        f"Yuborilmadi (bloklangan/o'chirilgan): {failed}"
    )
    return ConversationHandler.END


async def broadcast_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bekor qilindi.")
    return ConversationHandler.END


async def send_post_for_code(code: str, target_chat_id: int, context: ContextTypes.DEFAULT_TYPE, reply_markup=None):
    """Berilgan kodga mos postni topib, target_chat_id'ga yuboradi.
    Muvaffaqiyatli bo'lsa yuborilgan xabar obyektini, aks holda None qaytaradi."""
    row = get_post_by_code(code)
    if row is None:
        return None

    chat_id, message_id, preview = row
    try:
        sent = await context.bot.copy_message(
            chat_id=target_chat_id,
            from_chat_id=chat_id,
            message_id=message_id,
            reply_markup=reply_markup,
        )
        return sent
    except Exception:
        logger.exception("Postni yuborishda xatolik: kod=%s", code)
        return None


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Foydalanuvchi kod yuborganda (yoki pastdagi tugmani bosganda) ishlaydi."""
    text = (update.message.text or "").strip()

    if text.startswith("/"):
        return

    user_id = update.effective_user.id
    save_user(update.effective_chat.id)
    keyboard = None if is_admin(user_id) else main_menu_markup()

    # Pastdagi doimiy tugmalar
    if text == BTN_KINOLAR:
        await list_movies(update, context)
        return

    if text == BTN_VIP:
        sent = await send_post_for_code(
            VIP_CODE, update.effective_chat.id, context, reply_markup=keyboard
        )
        if sent is None:
            sent = await update.message.reply_text(
                "⭐ VIP post hali qo'shilmagan.\n"
                f"(Admin uchun: /add orqali post qo'shing va kod sifatida "
                f"\"{VIP_CODE}\" yozing)",
                reply_markup=keyboard,
            )
        await track_and_trim(update, context, sent)
        return

    # Oddiy kod sifatida qidiramiz
    sent = await send_post_for_code(
        text, update.effective_chat.id, context, reply_markup=keyboard
    )
    if sent is None:
        sent = await update.message.reply_text(
            "❌ Bunday kodli post topilmadi yoki uni yuborishda xatolik yuz berdi.\n"
            "Kodni tekshirib qaytadan yuboring, yoki pastdagi tugmalardan foydalaning.",
            reply_markup=keyboard,
        )
    await track_and_trim(update, context, sent)


async def handle_list_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/list dagi inline tugma bosilganda ishlaydi."""
    query = update.callback_query
    await query.answer()  # tugmadagi "yuklanmoqda" holatini olib tashlaydi

    if not query.data or not query.data.startswith("code:"):
        return
    code = query.data[len("code:"):]

    user_id = update.effective_user.id
    save_user(query.message.chat_id)
    reply_markup = None if is_admin(user_id) else main_menu_markup()

    sent = await send_post_for_code(
        code, query.message.chat_id, context, reply_markup=reply_markup
    )
    if sent is None:
        sent = await query.message.reply_text(
            "❌ Bu post topilmadi (o'chirilgan bo'lishi mumkin).",
            reply_markup=reply_markup,
        )

    await track_and_trim(update, context, sent)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error("Xatolik yuz berdi:", exc_info=context.error)


def main():
    init_db()
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    add_conversation = ConversationHandler(
        entry_points=[
            CommandHandler("add", add_start),
            CallbackQueryHandler(add_start, pattern=r"^adm:add$"),
        ],
        states={
            WAITING_POST: [
                MessageHandler(filters.ALL & ~filters.COMMAND, add_receive_post),
            ],
            WAITING_CODES: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_receive_codes),
            ],
            WAITING_BUTTON_NAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_receive_button_name),
            ],
        },
        fallbacks=[CommandHandler("cancel", add_cancel)],
    )

    edit_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(edit_field_start, pattern=r"^adm:editcodes:\d+$"),
            CallbackQueryHandler(edit_field_start, pattern=r"^adm:editname:\d+$"),
        ],
        states={
            WAITING_EDIT_VALUE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, edit_receive_value),
            ],
        },
        fallbacks=[CommandHandler("cancel", edit_cancel)],
    )

    broadcast_conversation = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(broadcast_start, pattern=r"^adm:broadcast$"),
        ],
        states={
            WAITING_BROADCAST_POST: [
                MessageHandler(filters.ALL & ~filters.COMMAND, broadcast_receive_post),
            ],
        },
        fallbacks=[CommandHandler("cancel", broadcast_cancel)],
    )

    app.add_handler(add_conversation)
    app.add_handler(edit_conversation)
    app.add_handler(broadcast_conversation)
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("list", list_movies))
    app.add_handler(CommandHandler("delete", delete_command))
    app.add_handler(CommandHandler("admin", admin_command))

    app.add_handler(CallbackQueryHandler(handle_list_button, pattern=r"^code:"))
    app.add_handler(CallbackQueryHandler(adm_menu_callback, pattern=r"^adm:menu$"))
    app.add_handler(CallbackQueryHandler(adm_editlist_callback, pattern=r"^adm:editlist$"))
    app.add_handler(CallbackQueryHandler(adm_postdetail_callback, pattern=r"^adm:editpost:\d+$"))
    app.add_handler(CallbackQueryHandler(adm_delpost_confirm_callback, pattern=r"^adm:delpost:\d+$"))
    app.add_handler(CallbackQueryHandler(adm_delpost_do_callback, pattern=r"^adm:delconfirm:\d+$"))

    app.add_error_handler(error_handler)

    # Foydalanuvchi matn (kod) yuborsa
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    logger.info("Bot ishga tushdi...")
    app.run_polling()


if __name__ == "__main__":
    main()
